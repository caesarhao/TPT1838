

#include <linux/module.h> 
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/clk.h>
#include <linux/err.h>
#include <linux/io.h>
#include <linux/delay.h>

#include <mach/iomap.h>

struct clk *clk_fuse;

static u32 tegra_fuse_readl(unsigned long offset)
{
	return readl(IO_TO_VIRT(TEGRA_FUSE_BASE+offset));
}

static void tegra_fuse_writel(u32 value, unsigned long offset)
{
	writel(value, IO_TO_VIRT(TEGRA_FUSE_BASE+offset));
}

#define FUSE_CTRL	0x000
#define STATE_IDLE	(0x4 << 16)

#define FUSE_REG_ADDR		0x004
#define FUSE_REG_READ		0x008
#define FUSE_REG_WRITE		0x00C

static void wait_for_idle(void)
{
	u32 reg;
	do {
		udelay(1);
		reg = tegra_fuse_readl(FUSE_CTRL);
	} while ((reg & (0xF << 16)) != STATE_IDLE);
}

#define FUSE_READ		0x1
#define FUSE_WRITE		0x2
#define FUSE_SENSE		0x3
#define FUSE_CMD_MASK	0x3

static u32 fuse_cmd_read(u32 addr)
{
	u32 reg;
	wait_for_idle();
	tegra_fuse_writel(addr, FUSE_REG_ADDR);
	reg = tegra_fuse_readl(FUSE_CTRL);
	reg &= ~FUSE_CMD_MASK;
	reg |= FUSE_READ;
	tegra_fuse_writel(reg, FUSE_CTRL);
	wait_for_idle();

	reg = tegra_fuse_readl(FUSE_REG_READ);
	return reg;
}

/*
static void fuse_cmd_write(u32 value, u32 addr)
{
	u32 reg;

	wait_for_idle();
	tegra_fuse_writel(addr, FUSE_REG_ADDR);
	tegra_fuse_writel(value, FUSE_REG_WRITE);

	reg = tegra_fuse_readl(FUSE_CTRL);
	reg &= ~FUSE_CMD_MASK;
	reg |= FUSE_WRITE;
	tegra_fuse_writel(reg, FUSE_CTRL);
	wait_for_idle();
}*/

static void fuse_cmd_sense(void)
{
	u32 reg;
	wait_for_idle();
	reg = tegra_fuse_readl(FUSE_CTRL);
	reg &= ~FUSE_CMD_MASK;
	reg |= FUSE_SENSE;
	tegra_fuse_writel(reg, FUSE_CTRL);
	wait_for_idle();
}

static int __init module_start(void)
{
	printk("<1>---------------------------------\n");
	printk("<1>Module is loaded\n");
	printk("<1>---------------------------------\n");
	clk_fuse = clk_get_sys("fuse-tegra", "fuse_burn");
	if (!IS_ERR_OR_NULL(clk_fuse)) {
		printk("<1>clk_enable ...\n");
		clk_enable(clk_fuse);
		printk("<1>fuse_cmd_sense ...\n");
		fuse_cmd_sense();

#if 0				
		{
			u32 out[4] = {0, 0, 0, 0};

			// SBK
			u32 offset = 0x0E;
			int start_bit = 22;
			int nbits = 128;

/*			// Device Key
			u32 offset = 0x16;
			int start_bit = 22;
			int nbits = 32; */

			u32 *dst = out;
			int i;
			int dst_bit = 0;
			u32 val;
			int loops;
			
			do {
				val = fuse_cmd_read(offset);
				printk("<1>fuse_cmd_read(%02x) = %08x\n", offset, val);
				loops = min(nbits, 32 - start_bit);
				for (i = 0; i < loops; i++) {
					if (val & (BIT(start_bit + i)))
						*dst |= BIT(dst_bit);
					else
						*dst &= ~BIT(dst_bit);
					dst_bit++;
					if (dst_bit == 32) {
						dst++;
						dst_bit = 0;
					}
				}
				nbits -= loops;
				offset += 2;
				start_bit = 0;
			} while (nbits > 0);
			
			printk("<1>SBK: %08x %08x %08x %08x\n", out[0], out[1], out[2], out[3]);
		}
#else
		{
			u32 out[4] = {0, 0, 0, 0};
			u32 offset = 0x0;
			
			for(offset=0; offset<256; offset+=8) {
				out[0] = fuse_cmd_read(offset+0);
				out[1] = fuse_cmd_read(offset+2);
				out[2] = fuse_cmd_read(offset+4);
				out[3] = fuse_cmd_read(offset+6);
				printk("<1>%04x: %08x %08x %08x %08x\n", offset, out[0], out[1], out[2], out[3]);
			}
		}

#endif		
		printk("<1>clk_disable ...\n");
		clk_disable(clk_fuse);
	} else {
		printk("<1>Error get fuse clk\n");
	}
	
	return 0;
}

static void __exit module_stop(void)
{
	printk("<1>Module is unloaded\n");
}

module_init(module_start);
module_exit(module_stop);
